@echo off
set GRADLE_VERSION=8.9
set CACHE_DIR=%USERPROFILE%\.cache\adiel-math-solver
set GRADLE_HOME=%CACHE_DIR%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  powershell -Command "Invoke-WebRequest -Uri https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip -OutFile '%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip'"
  powershell -Command "Expand-Archive -Force '%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip' '%CACHE_DIR%'"
)
call "%GRADLE_HOME%\bin\gradle.bat" --no-daemon assembleDebug
echo APK created at app\build\outputs\apk\debug\app-debug.apk
