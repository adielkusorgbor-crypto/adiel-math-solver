#!/usr/bin/env bash
set -euo pipefail
GRADLE_VERSION=8.9
CACHE_DIR="${HOME}/.cache/adiel-math-solver"
GRADLE_HOME="${CACHE_DIR}/gradle-${GRADLE_VERSION}"
mkdir -p "${CACHE_DIR}"
if [ ! -x "${GRADLE_HOME}/bin/gradle" ]; then
  ZIP="${CACHE_DIR}/gradle-${GRADLE_VERSION}-bin.zip"
  if command -v curl >/dev/null 2>&1; then
    curl -L "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "${ZIP}"
  else
    echo "Please install curl or download Gradle ${GRADLE_VERSION} manually."
    exit 1
  fi
  unzip -q -o "${ZIP}" -d "${CACHE_DIR}"
fi
"${GRADLE_HOME}/bin/gradle" --no-daemon assembleDebug
echo "APK created at: app/build/outputs/apk/debug/app-debug.apk"
