ADIEL KUSORGBOR MATH SOLVER — NATIVE ANDROID PROJECT

This is an Android Studio project that wraps the supplied math solver in an Android app with a home-screen icon. The maths calculator is bundled inside the app, so the solver itself works offline.

BUILD A DIRECT-INSTALL APK
Option A — Android Studio (recommended):
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Extract this ZIP.
3. In Android Studio, choose Open and select this folder (the folder containing settings.gradle).
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.
7. Copy app-debug.apk to your Android phone, tap it, and allow installation from that source if Android asks.

Option B — command line:
- Install Android SDK Platform 35 and Android Build Tools using Android Studio's SDK Manager.
- Install Java 17 or newer.
- Run ./build-apk.sh on macOS/Linux, or build-apk.bat on Windows.
- The script downloads Gradle 8.9 on first run and builds the debug APK.

IMPORTANT LIMITATION
This chat environment does not have the Android SDK or Gradle installed, so it cannot compile and attach the final APK directly here. This project contains the app source and build configuration needed to generate it. The first build requires internet access to download Gradle/dependencies and an Android SDK installation.

APP DETAILS
Name: Adiel Kusorgbor Math Solver
Package ID: com.adielkusorgbor.mathsolver
Minimum Android version: Android 6.0 (API 23)
